# -*- coding: utf-8 -*-
"""
Django Extensions abstract base model classes.
"""
import uuid
from django.db import models
from django.db.models import QuerySet
from django.utils.timezone import now
from django.utils.translation import ugettext_lazy as _

from django_extensions.db.fields import (
    AutoSlugField, CreationDateTimeField, ModificationDateTimeField,
)


class TimeStampedModel(models.Model):
    """ TimeStampedModel
    An abstract base class model that provides self-managed "created" and
    "modified" fields.
    """
    created = CreationDateTimeField(_('created'))
    modified = ModificationDateTimeField(_('modified'))

    def save(self, **kwargs):
        self.update_modified = kwargs.pop('update_modified', getattr(self, 'update_modified', True))
        super(TimeStampedModel, self).save(**kwargs)

    class Meta:
        get_latest_by = 'modified'
        ordering = ('-modified', '-created',)
        abstract = True


class TitleDescriptionModel(models.Model):
    """ TitleDescriptionModel
    An abstract base class model that provides title and description fields.
    """
    title = models.CharField(_('title'), max_length=255)
    description = models.TextField(_('description'), blank=True, null=True)

    class Meta:
        abstract = True


class TitleSlugDescriptionModel(TitleDescriptionModel):
    """ TitleSlugDescriptionModel
    An abstract base class model that provides title and description fields
    and a self-managed "slug" field that populates from the title.
    """
    slug = AutoSlugField(_('slug'), populate_from='title')

    class Meta:
        abstract = True


class ActivatorQuerySet(models.query.QuerySet):
    """ ActivatorQuerySet
    Query set that returns statused results
    """
    def active(self):
        """ Returns active query set """
        return self.filter(status=ActivatorModel.ACTIVE_STATUS)

    def inactive(self):
        """ Returns inactive query set """
        return self.filter(status=ActivatorModel.INACTIVE_STATUS)


class ActivatorModelManager(models.Manager):
    """ ActivatorModelManager
    Manager to return instances of ActivatorModel: SomeModel.objects.active() / .inactive()
    """
    def get_queryset(self):
        """ Use ActivatorQuerySet for all results """
        return ActivatorQuerySet(model=self.model, using=self._db)

    def active(self):
        """ Returns active instances of ActivatorModel: SomeModel.objects.active(),
        proxy to ActivatorQuerySet.active """
        return self.get_queryset().active()

    def inactive(self):
        """ Returns inactive instances of ActivatorModel: SomeModel.objects.inactive(),
        proxy to ActivatorQuerySet.inactive """
        return self.get_queryset().inactive()


class ActivatorModel(models.Model):
    """ ActivatorModel
    An abstract base class model that provides activate and deactivate fields.
    """
    INACTIVE_STATUS = 0
    ACTIVE_STATUS = 1

    STATUS_CHOICES = (
        (INACTIVE_STATUS, _('Inactive')),
        (ACTIVE_STATUS, _('Active')),
    )
    status = models.IntegerField(_('status'), choices=STATUS_CHOICES, default=ACTIVE_STATUS)
    activate_date = models.DateTimeField(blank=True, null=True, help_text=_('keep empty for an immediate activation'))
    deactivate_date = models.DateTimeField(blank=True, null=True, help_text=_('keep empty for indefinite activation'))
    objects = ActivatorModelManager()

    class Meta:
        ordering = ('status', '-activate_date',)
        abstract = True

    def save(self, *args, **kwargs):
        if not self.activate_date:
            self.activate_date = now()
        super(ActivatorModel, self).save(*args, **kwargs)


class SoftDeletableQuerySet(QuerySet):
    """QuerySet for SoftDeletableModel. Instead of deleting instance sets its
    'is_deleted' field to True.
    """

    def delete(self, soft=True):
        """
        Soft delete objects from queryset -> set the 'is_deleted'
        field to True.
        :return: None
        """
        if soft:
            self.update(is_deleted=True)
        else:
            super().delete()


class SoftDeletableManager(models.Manager):
    """
    Manager that limits the queryset by default to show only not deleted
    instances of model.
    """
    _queryset_class = SoftDeletableQuerySet

    def get_queryset(self):
        """
        Over this function to return queryset limited to not deleted entries.
        :return: QuerySet
        """
        kwargs = {'model': self.model, 'using': self._db}
        if hasattr(self, '_hints'):
            kwargs['hints'] = self._hints

        return self._queryset_class(**kwargs).filter(is_deleted=False)


class SoftDeletableModel(models.Model):
    """
    An abstract base class model with a ``is_deleted`` field that
    marks entries that are not going to be used anymore, but are
    kept in db for any reason.
    Default manager returns only not-deleted entries.
    """
    is_deleted = models.BooleanField(default=False)

    class Meta:
        abstract = True

    objects = SoftDeletableManager()

    def delete(self, using=None, soft=True, *args, **kwargs):
        """
        Soft delete object (set its ``is_deleted`` field to True).
        Actually delete object if setting ``soft`` to False.
        """
        if soft:
            self.is_deleted = True
            self.save(using=using)
        else:
            return super(SoftDeletableModel, self).delete(using=using, *args, **kwargs)


class BasicModel(SoftDeletableModel):
    """
    An abstract base class model with some basic field
    (uuid, created_time, last_change_time).
    """
    uuid = models.UUIDField(default=uuid.uuid1, unique=True, editable=False, max_length=64)
    created_time = models.DateTimeField(auto_now_add=True)
    last_change_time = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True
