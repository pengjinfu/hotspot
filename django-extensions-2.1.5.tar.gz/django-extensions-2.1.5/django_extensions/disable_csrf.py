import logging

from django.utils.deprecation import MiddlewareMixin

logger = logging.getLogger('error_logger')
logger_operate = logging.getLogger('operate')


class LoggerErrorMiddleware(MiddlewareMixin):
    @staticmethod
    def process_exception(request, exception):
        logger.exception(exception)


class DisableCSRFCheckMiddleware(MiddlewareMixin):
    """使用这个完全禁用Django的csrf检查 因为Django的csrf检查是可以关掉的，但是Django rest framework的csrf检查没办法关闭
    """

    @staticmethod
    def process_request(request):
        setattr(request, '_dont_enforce_csrf_checks', True)

    @staticmethod
    def process_response(request, response):
        response["Access-Control-Allow-Headers"] = "*"
        response["Access-Control-Allow-Methods"] = "*"

        response["Access-Control-Max-Age"] = "60"
        return response


class CEPCLogMiddleware(MiddlewareMixin):
    """使用这个完全禁用Django的csrf检查 因为Django的csrf检查是可以关掉的，但是Django rest framework的csrf检查没办法关闭
    """

    def process_request(self, request):
        pass

    @staticmethod
    def process_response(request, response):
        logger_operate.info('user:%s request:%s ' % (request.user, request,))
        return response
