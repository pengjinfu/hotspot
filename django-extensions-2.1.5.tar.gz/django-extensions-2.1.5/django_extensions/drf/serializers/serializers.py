from rest_framework import serializers

from django_extensions.drf.serializers.mixins import FlexFieldsSerializerMixin


class FlexFieldsModelSerializer(FlexFieldsSerializerMixin,
                                serializers.ModelSerializer):
    pass


class BasicModelSerializer(serializers.ModelSerializer):
    uuid = serializers.UUIDField(format='hex_verbose', read_only=True)
    created_time = serializers.DateTimeField(
        format='%Y-%m-%d %H:%M:%S', read_only=True)
    last_change_time = serializers.DateTimeField(
        format="%Y-%m-%d %H:%M:%S", read_only=True)

    def get_field_names(self, declared_fields, info):
        fields = super(BasicModelSerializer, self).get_field_names(declared_fields, info)
        fields = list(fields)
        try:
            fields.remove('is_deleted')
        except ValueError:
            pass
        return tuple(fields)

    class Meta:
        abstract = True


class CreatorModelSerializer(serializers.ModelSerializer):
    creator = serializers.HiddenField(
        default=serializers.CurrentUserDefault()
    )

    class Meta:
        abstract = True


class BasicCreatorModelSerializer(BasicModelSerializer):
    creator = serializers.SerializerMethodField()

    class Meta:
        abstract = True

    @staticmethod
    def get_creator(obj):
        return obj.creator.name


# region --------------- 动态序列化-------------------------

class LqFlexFieldsModelSerializer(FlexFieldsModelSerializer, BasicModelSerializer):
    """
    add the flex field support.
    """
    pass

# endregion ------------- end 动态序列化 ----------------------
