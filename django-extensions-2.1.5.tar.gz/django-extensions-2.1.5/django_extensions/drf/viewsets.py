import re

from rest_framework import viewsets, status, exceptions
from rest_framework.mixins import UpdateModelMixin, CreateModelMixin, ListModelMixin, RetrieveModelMixin
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet, GenericViewSet, ReadOnlyModelViewSet

from django_extensions.drf.mixins import FlexFieldsMixin
from django_extensions.utils.http_response import Http201Response, Http400Response


# region --------------- 基础ViewSet ---------------

class BasicModelViewSet(ModelViewSet):
    def get_serializer_name(self):
        return re.sub(r'(_\w)', lambda x: x.group(0)[1].upper(),
                      self.action.replace('get_', '').replace('set_', '').replace('partial_', '').capitalize())

    def get_serializer_class(self):
        if hasattr(self.serializer_class, self.get_serializer_name()):
            return getattr(self.serializer_class, self.get_serializer_name())
        else:
            return self.serializer_class.Retrieve

    def create(self, request, *args, **kwargs):
        """
        Overwrite this function to return different
        serializer when created a object.
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        serializer = self.get_serializer(data=kwargs.get('data', request.data))
        serializer.is_valid(raise_exception=True)
        instance = self.perform_create(serializer)
        serializer = self.serializer_class.Retrieve(
            instance=instance, context=self.get_serializer_context())
        headers = self.get_success_headers(serializer.data)
        return Http201Response(data=serializer.data, headers=headers)

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data,
                                         partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)

        if getattr(instance, '_prefetched_objects_cache', None):
            # If 'prefetch_related' has been applied to a queryset, we need to
            # forcibly invalidate the prefetch cache on the instance.
            instance._prefetched_objects_cache = {}

        # change this for update return different ser
        serializer = self.serializer_class.Retrieve(instance)
        return Response(serializer.data)

    def perform_create(self, serializer):
        return serializer.save()


class BasicReadOnlyModelViewSet(ReadOnlyModelViewSet):
    # 获取列表是必须筛选字段
    required_filter_fields = None

    def get_serializer_name(self):
        return re.sub(r'(_\w)', lambda x: x.group(0)[1].upper(),
                      self.action.replace('get_', '').replace('set_', '').replace('partial_', '').capitalize())

    def get_serializer_class(self):
        if hasattr(self.serializer_class, self.get_serializer_name()):
            return getattr(self.serializer_class, self.get_serializer_name())
        else:
            return self.serializer_class.Retrieve
            # raise Http404

    def list(self, request, *args, **kwargs):

        if self.required_filter_fields and set(self.required_filter_fields).issubset(set(request.GET.keys())) is False:
            raise Http400Response()
        return ReadOnlyModelViewSet.list(self, request, *args, **kwargs)


class BasicGenericViewSet(GenericViewSet):
    def permission_denied(self, request, message=None):
        """
        If request is not permitted, determine what kind of exception to raise.
        """
        if request.authenticators and not request.successful_authenticator:
            raise exceptions.NotAuthenticated()
        raise exceptions.PermissionDenied(detail=message)

    def get_serializer_name(self):
        return re.sub(r'(_\w)', lambda x: x.group(0)[1].upper(),
                      self.action.replace('get_', '').replace('set_', '').replace('partial_', '').capitalize())

    def get_serializer_class(self):
        if hasattr(self.serializer_class, self.get_serializer_name()):
            return getattr(self.serializer_class, self.get_serializer_name())
        else:
            return self.serializer_class.Retrieve

    def initial(self, request, *args, **kwargs):
        """
        Runs anything that needs to occur prior to calling the method handler.
        """

        # noinspection PyAttributeOutsideInit
        self.format_kwarg = self.get_format_suffix(**kwargs)

        # Perform content negotiation and store the accepted info on the request
        neg = self.perform_content_negotiation(request)
        request.accepted_renderer, request.accepted_media_type = neg

        # Determine the API version, if versioning is in use.
        version, scheme = self.determine_version(request, *args, **kwargs)
        request.version, request.versioning_scheme = version, scheme

        # Ensure that the incoming request is permitted
        self.perform_authentication(request)
        self.check_permissions(request)
        self.check_throttles(request)


class BasicCreateModelMixin(CreateModelMixin):
    def create(self, request, *args, **kwargs):
        """
        Overwrite this function to return different
        serializer when created a object.
        """
        serializer = self.get_serializer(data=kwargs.get('data', request.data))
        serializer.is_valid(raise_exception=True)
        instance = self.perform_create(serializer)
        # 这里添加上下文进去 否则阔能报错 -- by qsh
        serializer = self.serializer_class.Retrieve(instance=instance, context=self.get_serializer_context())
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED,
                        headers=headers)

    def perform_create(self, serializer):
        return serializer.save()


class BasicUpdateModelMixin(UpdateModelMixin):
    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=kwargs.get('data', request.data), partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)

        if getattr(instance, '_prefetched_objects_cache', None):
            # If 'prefetch_related' has been applied to a queryset, we need to
            # forcibly invalidate the prefetch cache on the instance.
            instance._prefetched_objects_cache = {}

        serializer = self.serializer_class.Retrieve(instance)
        return Response(serializer.data)


# endregion ------------------end 基础ViewSet -----------------------------------


class FlexFieldsModelViewSet(FlexFieldsMixin, viewsets.ModelViewSet):
    pass


# region ------------------动态序列化 viewSet--------------
class LqGenericViewSet(GenericViewSet):
    """
    Overwrite GenericViewSet to add custom methods.
    """

    def get_serializer_name(self):
        return re.sub(r'(_\w)', lambda x: x.group(0)[1].upper(),
                      self.action.replace('get_', '').replace('set_', '').replace('partial_', '').capitalize())

    def get_serializer_class(self):
        if hasattr(self.serializer_class, self.get_serializer_name()):
            return getattr(self.serializer_class, self.get_serializer_name())
        else:
            return self.serializer_class.Retrieve
            # raise Http400Response(debug_msg='请求方法不存在')


class LqBasicFlexModelViewSet(FlexFieldsMixin, LqGenericViewSet):
    """
    only use mixin otherwise may cause err. -- by Lq
    """
    pass


class LqReadOnlyModelViewSet(ListModelMixin, LqGenericViewSet):
    """
    this view set only could get list.
    """
    pass


class LqReadOnlyModelObjectViewSet(LqReadOnlyModelViewSet, RetrieveModelMixin):
    """
    this view set could get object.
    """
    pass

# endregion -------------------- end 动态序列化 viewSet -----------------
