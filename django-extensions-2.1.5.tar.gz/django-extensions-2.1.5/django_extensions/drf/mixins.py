from __future__ import unicode_literals

from rest_framework import status
from rest_framework.mixins import CreateModelMixin, UpdateModelMixin
from rest_framework.response import Response

from django_extensions.utils.http_response import Http201Response


class CreateRetUsingDifSerModelMixin(CreateModelMixin):
    """
    this mixin will using different class to create.
    """

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        instance = self.perform_create(serializer)
        serializer = self.serializer_class.Retrieve(
            instance=instance, context=self.get_serializer_context())
        headers = self.get_success_headers(serializer.data)
        return Http201Response(data=serializer.data, headers=headers)

    def perform_create(self, serializer):
        return serializer.save()


class FlexFieldsMixin(object):
    permit_list_expands = []
    _expandable = True
    _force_expand = []

    def list(self, request, *args, **kwargs):
        """
            Prevent expansion by default; add fields to "permit_list_expands"
            to whitelist particular fields.
        """
        self._expandable = False
        expand = request.query_params.get('expand')

        if len(self.permit_list_expands) > 0 and expand:
            if expand == '~all':
                self._force_expand = self.permit_list_expands
            else:
                self._force_expand = list(
                    set(expand.split(',')) & set(self.permit_list_expands))

        return super(FlexFieldsMixin, self).list(request, *args, **kwargs)

    def get_serializer_context(self):
        default_context = super(FlexFieldsMixin, self).get_serializer_context()
        default_context['expandable'] = self._expandable
        default_context['force_expand'] = self._force_expand
        return default_context


class LqCreateModelMixin(CreateModelMixin):
    """
    Create a model instance
    """
    def create(self, request, *args, **kwargs):
        """
        Overwrite this function to return different
        serializer when created a object.
        """
        serializer = self.get_serializer(data=kwargs.get('data', request.data))
        serializer.is_valid(raise_exception=True)
        instance = self.perform_create(serializer)
        # 这里添加上下文进去 否则阔能报错 -- by qsh
        serializer = self.serializer_class.Retrieve(
                instance=instance, context=self.get_serializer_context())
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED,
                        headers=headers)

    def perform_create(self, serializer):
        return serializer.save()


class LqUpdateModelMixin(UpdateModelMixin):
    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance,
                                         data=kwargs.get('data', request.data),
                                         partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)

        if getattr(instance, '_prefetched_objects_cache', None):
            # If 'prefetch_related' has been applied to a queryset, we need to
            # forcibly invalidate the prefetch cache on the instance.
            instance._prefetched_objects_cache = {}

        serializer = self.serializer_class.Retrieve(instance)
        return Response(serializer.data)
