from django.conf import settings
from django.utils.translation import ugettext_lazy as _
# noinspection PyProtectedMember
from rest_framework.exceptions import APIException, _get_error_details
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK, HTTP_400_BAD_REQUEST, \
    HTTP_201_CREATED


class Http400Response(APIException):
    """
    Return the http 400 message.
    """
    status_code = HTTP_400_BAD_REQUEST
    default_detail = _('参数错误')

    def __init__(self, message=None, debug_msg=None):
        if message is None:
            detail = self.default_detail
        else:
            detail = _(message)

        if settings.DEBUG:
            if debug_msg is not None:
                detail = _(debug_msg)
        code = self.default_code

        self.detail = _get_error_details(detail, code)


class Http200Response(Response):
    status_code = HTTP_200_OK

    def __init__(self, message=None):
        if message is None:
            data = {'msg': 'success'}
        else:
            data = {'msg': message}
        super().__init__(data)


class Http201Response(Response):
    status_code = HTTP_201_CREATED

    def __init__(self, data=None, headers=None):
        super().__init__(data=data, headers=headers)

